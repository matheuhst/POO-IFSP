package aula0708;

import java.util.Scanner;

public class Produtos {
    public static void main(String[] args){
        Scanner scan = new Scanner(System.in);
        try {
        
        System.out.print("Insira o nome do produto: ");
        String produto = scan.nextLine();
        
        System.out.print("Insira o custo do produto: ");
        String custo = scan.nextLine();
        
        System.out.print("Insira o percentual de lucro que deseja ter: ");
        String percentual = scan.nextLine();
        
        double douCusto = Double.parseDouble(custo);
        double intPercentual = Double.parseDouble(percentual);
        
        double valorFinal = (1+(intPercentual/100))*douCusto;
        
        double lucro = valorFinal - douCusto;
        
        System.out.println("\nNome: " + produto);
        System.out.println("Custo: " + douCusto);
        System.out.println("Percentual de lucro: " + intPercentual);
        System.out.println("Valor a ser vendido: " + valorFinal);
        System.out.println("Lucro obtido: " + lucro);
        }
        catch (Exception e) {
            System.out.println("Erro ao converter número: " + e.getMessage());
        }

    }
}
