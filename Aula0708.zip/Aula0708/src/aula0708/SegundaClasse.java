package aula0708;

import java.util.Scanner;

public class SegundaClasse {
    
    public static void main(String[] args) {
        // Ler 2 números e imprimir a soma de ambos
        Scanner scan = new Scanner(System.in);
        System.out.print("Digite o primeiro número: ");
        String numero1 = scan.nextLine();
        
        System.out.print("Digite o segundo número: ");
        String numero2 = scan.nextLine();
        try {
            int strNum1 = Integer.parseInt(numero1);
            int strNum2 = Integer.parseInt(numero2);

            int soma = strNum1 + strNum2;

            String mensagem = String.format("A soma do número %d e do número %d é de %d", strNum1, strNum2, soma);
            System.out.println(mensagem);
        }
        catch (Exception e) {
            System.out.println("Erro ao converter número: " + e.getMessage());
        }
        
        
    }
}
