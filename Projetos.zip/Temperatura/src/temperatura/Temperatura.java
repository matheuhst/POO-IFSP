
package temperatura;

import java.util.Scanner;

public class Temperatura {
    public static void main(String[] args) {
        Scanner scan = new Scanner(System.in);
        
        boolean continuar = true;
        
        do {
        System.out.print("\nDigite uma temperatura em celsius: ");
        double celsius = Double.parseDouble(scan.nextLine());
        
        double faren = celsius * 1.8 + 32;
        double kelvin = celsius + 273.15;
        double reaumur = celsius * 0.8;
        double rankine = celsius *1.8 + 491.67;
        
        System.out.println("\nQuer converter para qual medida? ");
        System.out.print("[1] Fahrenheit\n[2] Kelvin\n[3] Reaumur\n[4] Rankine\n>>> ");
        int escolha = Integer.parseInt(scan.nextLine());
        
        double escolhida = celsius;
        String temp = "";

        do {
            switch (escolha) {
                case 1 -> {
                    escolhida = faren;
                    temp = "Fahrenheit";
                }
                case 2 -> {
                    escolhida = kelvin;
                    temp = "Kelvin";
                }
                case 3 -> {
                    escolhida = reaumur;
                    temp = "Reaumur";
                }
                case 4 -> {
                    escolhida = rankine;
                    temp = "Rankine";
                }
                default -> {System.out.println("\nEscolha apenas uma das opções.");

                }
            }
        } while (escolha < 1 || escolha > 4);
        
        System.out.format("\nA temperatura de %.1f graus Celsius eh igual a %.1f %s\n", celsius, escolhida, temp);
        
        System.out.print("Quer continuar? [S/N] \n>>> ");
        String resposta = scan.nextLine().toUpperCase();
        if (resposta.charAt(0) != 'S'){
            continuar = false;
        }

        } while (continuar);
        
    }
    
}
