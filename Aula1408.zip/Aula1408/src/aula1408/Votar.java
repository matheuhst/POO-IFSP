package aula1408;

import java.util.Scanner;

public class Votar {
    public static void main(String[] args){
        Scanner scan = new Scanner(System.in);
        System.out.println("Informe sua idade: ");
        int idade = Integer.parseInt(scan.nextLine());
        
        // Verificar se usuário pode ou não votar, e se ele é obrigado a votar ou não.
        if (idade >= 18 && idade < 70){
            System.out.println("Seu voto é obrigatório.");
        } else if (idade >= 16 || idade <= 17 && idade >= 70){
            System.out.println("Seu voto é facultativo.");
        } else {
            System.out.println("Você não precisa votar.");
        }
    }
}
