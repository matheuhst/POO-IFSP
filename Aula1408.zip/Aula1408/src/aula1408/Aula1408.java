package aula1408;

import java.util.Scanner;

public class Aula1408 {
    public static void main(String[] args) {
        Scanner scan = new Scanner(System.in);
        System.out.print("Informe a sua idade: ");
        int idade = Integer.parseInt(scan.nextLine());
        
        // Verificar e imprimir se usuário é maior de idade
        if (idade >= 18){
            System.out.println("Você é maior de idade.");
        }
        else {
            System.out.println("Você é menor de idade.");
        }
    }
    
}
