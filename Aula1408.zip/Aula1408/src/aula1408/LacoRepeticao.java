package aula1408;

import java.util.Scanner;

public class LacoRepeticao {
    public static void main(String[] args){
        Scanner scan = new Scanner(System.in);
        System.out.println("Informe um número: ");
        int num = Integer.parseInt(scan.nextLine());
        
        System.out.println("Informe um expoente: ");
        int expo = Integer.parseInt(scan.nextLine());
        
        int resultado = 1;
        
        for (int i = 0; i < expo; i++){
            resultado *= num;
        }
        System.out.println(num + " ^" + expo + " = " + resultado);
    }
}
