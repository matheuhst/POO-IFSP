
package aula1408;

import java.util.Scanner;

public class Nota {
    public static void main(String[] args){
        Scanner scan = new Scanner(System.in);        
        
        System.out.print("Informe a nota 1: ");
        double nota1 = Double.parseDouble(scan.nextLine());
        
        System.out.print("Informe a nota 2: ");
        double nota2 = Double.parseDouble(scan.nextLine());
        
        System.out.print("Informe a nota 3: ");
        double nota3 = Double.parseDouble(scan.nextLine());
        
        double soma = nota1 + nota2 + nota3;
        
        if (soma <= 10){
            //double media = (nota1 + nota2 + nota3) / 3;
            if (soma >= 6){
                System.out.println("Passou de ano.");
            } else if (soma >= 4){
                System.out.println("Recuperação.");
            } else {
                System.out.println("Reprovado.");
            }
        } else {
            System.out.println("ERRO.");
        }
    }
}
